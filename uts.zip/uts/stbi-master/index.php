<?php
include "header.php";
?>
<h3>Kuliah Information Retrieval<br>
UNIVERSITAS STIKUBANK SEMARANG<BR></h3>
<BR>
CREATED BY : <BR>
Nama : Helda Mentari M<br>
Nim : 14.01.55.0043<br>
Prodi : Sistem Informasi